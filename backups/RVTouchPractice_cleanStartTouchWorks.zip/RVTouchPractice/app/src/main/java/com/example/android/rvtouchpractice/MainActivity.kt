package com.example.android.rvtouchpractice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    // var lista = mutableListOf ("1", "2", "3", "4", "5", "6")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // get the viewmodel


        setupRv()


    }

    fun setupRv(){
        val rv: RecyclerView = findViewById(R.id.rv_view)
        val adapter = RVAdapter(lista)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        // setting up drag and swipe--CURRENTLY DOING WORK
        // callback from custom; parameter is the PartAdapter created in onCreate
        // this adapter includes/is the ItemTouchHelperAdapter
        val callback: ItemTouchHelper.Callback = TouchHelperCallback(adapter)
        // touchhelper created using generic class
        val touchHelper = ItemTouchHelper(callback)
        touchHelper.attachToRecyclerView(rv)

    }
}