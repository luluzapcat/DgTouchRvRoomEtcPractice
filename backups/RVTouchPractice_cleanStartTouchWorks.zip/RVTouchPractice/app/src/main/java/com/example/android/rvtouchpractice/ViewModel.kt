package com.example.android.rvtouchpractice

import com.example.android.rvtouchpractice.database.ItemDatabase
import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.android.rvtouchpractice.database.Item
import com.example.android.rvtouchpractice.database.ItemDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.ArrayList

// TRY THIS...
// Viewmodel accesses db, gets LiveData from db--CHECK THIS
// Viewmodel updates the db as needed using functions and co-routines
// LiveData stays updated on its own
// Fragment observes the LiveData & feeds it to the adapter
// the tricky part: keeping track of what things are live daya, mutable, arraylists, items...

class ItemViewModel (
    val database: ItemDao,
    application: Application) : AndroidViewModel(application) {

    // private var part = MutableLiveData<Part?>()
    val items = database.getItemsByOrder()

    // just for testing early, make some parts when touch a temporary button
    // calls createPart() which interacts with the database
    fun makeTestItems() {
        viewModelScope.launch {
            createItem("1")
            createItem("2")
            createItem("3")
            createItem("4")
            createItem("5")
            createItem("6")
        }
    }

    // create a new part, add it to the db
    suspend fun createItem(name: String) {
        if (name != "") {
            withContext(Dispatchers.IO) {
                val newItem = Item()
                newItem.name = name
                database.insert(newItem)
            }
        }
    }

    fun onTouchClearPartsButton() {
        viewModelScope.launch {
            clearParts()
        }
    }

    private suspend fun clearParts() {
        withContext(Dispatchers.IO) {
            database.clear()
        }
    }

    private var _showDialog = MutableLiveData<Boolean>()
    val showDialog: LiveData<Boolean>
        get() = _showDialog

    fun onTouchAddPartButton() {
        _showDialog.value = true
    }

    fun closeDialog() {
        Log.i("thing", "running closeDialog in viewModel")
        _showDialog.value = false
    }

    private suspend fun addPart(item: Item) {
        withContext(Dispatchers.IO) {
            database.insert(item)
        }
    }

    fun deletePart(item: Item) {
        viewModelScope.launch {
            database.delete(item)
        }
    }

    fun updatePart(item: Item) {
        viewModelScope.launch {
            database.update(item)
            checkDb()
        }
    }

    fun checkDb() {
        viewModelScope.launch {
            var differentOrder = database.getItemByName("different")
            Log.i("Tag", "checkDb order of different is $differentOrder")
        }
    }

    fun updateAllParts(data: MutableList<Item> = ArrayList()) {
        viewModelScope.launch {
            updateParts(data)
        }
    }

    private suspend fun updateParts(data: MutableList<Item> = ArrayList() ) {
        withContext(Dispatchers.IO) {
            for (item in data) {
                database.update(item)
                Log.i("tag", "called updateParts to update Room db from PartListViewModel fun")
            }
        }
    }
}