package com.example.android.rvtouchpractice

interface TouchHelperInterface {
    fun onItemMove(fromPosition: Int, toPosition: Int)
    fun onItemDismiss(position: Int)
}
