package com.example.android.rvtouchpractice

import android.content.ContentValues.TAG
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.example.android.rvtouchpractice.database.Item
import com.example.android.rvtouchpractice.database.ItemDatabase
import java.util.ArrayList

class MainActivity : AppCompatActivity() {

    var viewModel: ItemViewModel? = null
    var recyclerView: RecyclerView? = null
    var adapter: RVAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val application = this.application

        var texty: TextView = findViewById(R.id.test_text)


//        val database = ItemDatabase.getInstance(this.applicationContext)
        val database = Room.databaseBuilder(
            this,ItemDatabase::class.java, "item_database"
        )
            .allowMainThreadQueries()
            .build()

        database.itemDatabaseDao.insert(Item(name ="1", order = 1))
        database.itemDatabaseDao.insert(Item(name ="2", order = 2))
        database.itemDatabaseDao.insert(Item(name ="3", order = 3))

        val allItems = database.itemDatabaseDao.getAllItems()
        allItems.forEach{
            texty.append("\n" + it.name)
        }
        Log.i(TAG, "allItems size ${allItems.size}" )

        // this may do same as the builder above
        // val dataSource = ItemDatabase.getInstance(application).itemDatabaseDao
        // make the viewmodel

//        val viewModelFactory = ItemViewModelFactory(dataSource, application)
//        viewModel =
//            ViewModelProvider(
//                this, viewModelFactory
//            ).get(ItemViewModel::class.java)

        // viewModel?.userMutableLiveData?.observe(this, userListUpdateObserver)
//        viewModel?.viewModelMutableLiveDataArrayList?.observe(this, userListUpdateObserver)
//    }
        //Users live data
        var userListUpdateObserver: Observer<ArrayList<Item>?> =
            Observer<ArrayList<Item>?> { itemArrayList ->
                adapter = RVAdapter(this@MainActivity, allItems )
                recyclerView!!.layoutManager = LinearLayoutManager(this@MainActivity)
                recyclerView!!.adapter = adapter
            }
    }

//    fun setupRv(){
//        val rv: RecyclerView = findViewById(R.id.rv_view)
//        val adapter = RVAdapter(lista)
//        rv.layoutManager = LinearLayoutManager(this)
//        rv.adapter = adapter
//
//        // setting up drag and swipe--CURRENTLY DOING WORK
//        // callback from custom; parameter is the PartAdapter created in onCreate
//        // this adapter includes/is the ItemTouchHelperAdapter
//        val callback: ItemTouchHelper.Callback = TouchHelperCallback(adapter)
//        // touchhelper created using generic class
//        val touchHelper = ItemTouchHelper(callback)
//        touchHelper.attachToRecyclerView(rv)
//
//    }
}