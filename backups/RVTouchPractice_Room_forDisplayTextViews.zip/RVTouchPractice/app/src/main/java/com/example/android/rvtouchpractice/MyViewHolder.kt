package com.example.android.rvtouchpractice

import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MyViewHolder(val textView: TextView): RecyclerView.ViewHolder(textView)